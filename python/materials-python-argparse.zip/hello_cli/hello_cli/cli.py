"""CLI-related code for the Hello CLI package."""

"""Entry-point for the hello_cli package."""

"""Back-end model for the hello_cli app."""

"""Tests for CLI functionalities."""

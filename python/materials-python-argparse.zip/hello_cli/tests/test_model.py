"""Tests for model's functionalities."""
